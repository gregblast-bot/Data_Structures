#include <string>
#include <vector>
#include <iostream>
#include <locale> 
#include <algorithm>
#include "FindPalindrome.hpp"

using namespace std;

//------------------- HELPER FUNCTIONS -----------------------------------------

// non-class helper functions go here, should be declared as "static" so that
// their scope is limited

// helper function to convert string to lower case
static void convertToLowerCase(string & value)
{
	locale loc;
	for (unsigned int i=0; i<value.size(); i++) {
		value[i] = tolower(value[i],loc);
	}
}

// Check to see if the string is an allowable candidate
static bool allowableVectorCandidate(const vector<string> & stringVector)
{	
	for(unsigned int i = 0; i < stringVector.size(); i++){
		
		// Create a temporary variable to hold the string at the vector indices
		string temp = stringVector.at(i);
		
		for(unsigned int i = 0; i < temp.length(); i++){
			if((temp[i] <= 'z' && temp[i] >= 'a') || (temp[i] <= 'Z' && temp[i] >= 'A')){
				return false;
			}
				
			else{
				return true;
			}
		}
	}
}

// Check to see if the string is an allowable candidate
static bool allowableStringCandidate(const string & value)
{
		for(unsigned int i = 0; i < value.length(); i++){
			if((temp[i] <= 'z' && temp[i] >= 'a') || (temp[i] <= 'Z' && temp[i] >= 'A')){
				return true;
			}
				
			else{
				return false;
			}
		}
}

// Remove all spaces and punctuation with isalpha loop
static void sentenceToString(vector<string> & stringVector)
{
	// Create a string vector to hold the result
	vector<string> result;
	
	// Loop through the string vector
	for(unsigned int i = 0; i < stringVector.size(); i++){
		// Create temporary variables to hold the strings at the vector indices
		string temp1 = stringVector.at(i);
		string temp2 = result.at(i);
		
		// Loop through the elements of the string
		for(unsigned int j = 0; j < temp1.length(); j++){
			// If the element is alphabetical, put that value into result
			if(isalpha(temp1[i])){
				temp2[i] = temp1[i];
			}
		}
	}
}

// Recursive factorial function for the N! words
static int factorial(int n)
{
	// If n is greater than one do recursive stuff
    if(n > 1){
        return n * factorial(n - 1);
	}
	
	// Else return butt
    else{
        return 1;
	}
}

//------------------- PRIVATE CLASS METHODS ------------------------------------

// private recursive function. Must use this signature!
void FindPalindrome::recursiveFindPalindromes(vector<string>
        candidateStringVector, vector<string> currentStringVector)
{
	// Check to see if the number of palindromes exceeds N!
	if(num > factorial(num)){
		cout << "To many N words." << endl;
	}
	
	// Trun the sentence to a string
	sentenceToString(currentStringVector);
	sentenceToString(candidateStringVector);
	
	// Check to see if this word is okay
	if(allowableVectorCandidate(currentStringVector) == false){
		cout << "Something is wrong with your word(s)." << endl;
	}
	
	// Check to see if there are duplicate words/palidromes 
	else if(allowableVectorCandidate(currentStringVector) == true){
		
		// Algorithm for finding duplicates
		sort(currentStringVector.begin(), currentStringVector.end());
		vector<string>::iterator it = unique(currentStringVector.begin(), currentStringVector.end());
		bool wasUnique = (it == currentStringVector.end());
		
		if(wasUnique == false){
			cout << "Duplicates are not allowed." << endl;
		}
	}
	
	// If the current string vetor is empty, fall into this case
	else if(currentStringVector.empty()){
		string test;
		
		for(unsigned int i = 0; i < candidateStringVector.size(); i++){
			test = test + candidateStringVector.at(i);
		}	
		
			// If candidate string vector passes the palindrome test, fall into this case
			if(isPalindrome(test) == true){
				// Increment the number of palindromes
				num++;
				// Add the candidate string vector to our private palindrom vector
				palindromeVector.push_back(candidateStringVector);
			}
	}
	
	else{
		
		// Loop through the currentStringVector and create temporary variables 
		for(unsigned int i = 0; i < currentStringVector.size(); i++){
			vector<string> temp1 = currentStringVector;
			vector<string> temp2 = candidateStringVector;
			temp1.erase(temp1.begin() + 1);
			temp2.push_back(candidateStringVector[i]);
			
			// If current string and candidate string pass cut test 2, do recursion
			if(cutTest2(temp2, temp1) == false){
				recursiveFindPalindromes(temp2, temp1);
			}
		}	
	}
		
		
		/*//Reverse the current string vector so we can easily iterate through and keep order
		 * Not what I wanted to do but still coolio
		reverse(currentStringVector.begin(), currentStringVector.end());
		
		// Iterate through from the back of the vector to the front, the end is now the beginning
		for(int i = currentStringVector.size(); i >= 0; i--){
			// Create a temp variable to hold the string at the current string vector position
			string temp = currentStringVector.at(i);
			// Now, delete said string from current string vector
			currentStringVector.pop_back();
			// And, add the temp variable to candidate string vector
			candidateStringVector.push_back(temp);
			
			// If current string and candidate string pass cut test 2, do recursion
			if(cutTest2(currentStringVector, candidateStringVector) == true){
				recursiveFindPalindromes(candidateStringVector, currentStringVector);
			}
		}*/		
}

// private function to determine if a string is a palindrome (given, you
// may change this if you want)
bool FindPalindrome::isPalindrome(string currentString) const
{
	locale loc;
	// make sure that the string is lower case...
	convertToLowerCase(currentString);
	// see if the characters are symmetric...
	int stringLength = currentString.size();
	for (int i=0; i<stringLength/2; i++) {
		if (currentString[i] != currentString[stringLength - i - 1]) {
			return false;
		}
	}
	return true;
}

//------------------- PUBLIC CLASS METHODS -------------------------------------

/* Default constructor creates an empty vector for storing plaindomes,
 * initializes word to an empty string, num to zero, and truth to false.
 */ 
FindPalindrome::FindPalindrome()
{
	vector<string> palindrome = {};
	vector<vector<std::string>> palindromeVector = {{}};
	num = 0;
	
}

//Destructor for our vector palindrome, deletes from memory
FindPalindrome::~FindPalindrome()
{
	palindromeString.~vector<string>();
	//palindromeVector.~vector<vector<string>>; Nope, not havin' it
}

// Return the number of palindromes that have been found
int FindPalindrome::number() const
{
	return num;
}

// Clear the palindrome string and palindrome vector of all elements
// Set the number of palindromes to zero
void FindPalindrome::clear()
{
	palindromeString.clear();
	palindromeVector.clear();
	num = 0;
}

/* Cut test 1 checks whether the string is even or odd, performs specfic
 * operations based on that and returns a bool value determining if the
 * string vector is viable
 */ 
bool FindPalindrome::cutTest1(const vector<string> & stringVector)
{
	// Initalize variables 
	int count1, count2, count3;
	
	// Turn the string vector into one long string
	for(unsigned int i = 0; i < stringVector.size(); i++){
		string temp;
		temp = temp + stringVector.at(i);
		
		// Count the length of the string		
		for(unsigned int j = 0; j < temp.length(); j++){
					count1++;
		}
	}	
	
	// If the string vector is even, fall into this case	
	if(count1 % 2 == 0){
		// Convert the string vector to one long string
		for(unsigned int i = 0; i < stringVector.size(); i++){
			string temp;
			temp = temp + stringVector.at(i);
			
			// Loop thru to half the length
			for(unsigned int j = 0; j < temp.length()/2; j++){
				
				// If the jth letter and the lenth-jth letter are equal, continue returning true
				if(temp[j] == (temp.length()-j)){
					return true;
				}
				
				else{
					return false;
				}
			}
		}
	}
	
	// If the string vector is odd, fall into this case
	else{
		// Convert the string vector to one long string
		for(unsigned int i = 0; i < stringVector.size(); i++){
			string temp1;
			temp1 = temp1 + stringVector.at(i);
			
			//Loop thru the length of the string
			for(unsigned int j = 0; j < temp1.length(); j++){
			  // Create a char variable to hold the middle letter
			  char temp2;
			  temp2 = temp1.length()/2; 
				// If the jth letter of the string equal the middle character add to count2
				if(temp2 == temp1[j]){
					count2++;
				}
				// Else add to count three
				else{
					count3++;
				}
			}
		}
		
		/* If count2-1 (because we counted the middle letter) is odd and 
		 * count3 (the rest of the letters) is even, return true
		 */
		if((count2-1) % 2 == 1 && count3 % 2 == 0){
			return true;
		}
		
		else{
			return false;
		}
	}
}

/* Analyze the vectors seperately, if the leftmost half of the string vector
 * is equal to the leftmost half, it passes the test.
 */  
bool FindPalindrome::cutTest2(const vector<string> & stringVector1,
                              const vector<string> & stringVector2)
{

	for(unsigned int i = 0; i < stringVector1.size(); i++){
			// Do some substring vodoo
			string temp1 = stringVector1.at(i);
			string left1 = temp1.substr(0, stringVector1.size()/2);
			string right1 = temp1.substr(stringVector1.size()/2, stringVector1.size());
			// Make right1 backwards
			reverse(right1.begin(), right1.end());
				
				if(left1 == right1){
					return true;
				} 
	
				else{
					return false;
				}
	}
			
	for(unsigned int j = 0; j < stringVector2.size(); j++){	
			// Do some substring vodoo
			string temp2 = stringVector2.at(j);
			string left2 = temp2.substr(0, stringVector2.size()/2);
			string right2 = temp2.substr(stringVector2.size()/2, stringVector2.size());
			// Make right2 backwards
			reverse(right2.begin(), right2.end());
				
				if(left2 == right2){
					return true;
				} 
	
				else{
					return false;
				}
	}
}

bool FindPalindrome::add(const string & value)
{
	// Check if the string is an allowable candidate and add to palindromeString
	if(allowableStringCandidate(value) == true){
		palindromeString.push_back(value);
		return true;
	}
	
	else{
		return false;
	}
	
	// Call recursive function, pass in plaindromeString and empty vector of strings
	recursiveFindPalindromes(palindromeString, Empty);
}

bool FindPalindrome::add(const vector<string> & stringVector)
{
	// Iterator string vector for insert function
	vector<string>::iterator it;
	
	// Add for loop and convert to string if insert doesn't work
	// Check if this is an allowable vector and insert it in palidromeString if it is
	if(allowableVectorCandidate(stringVector) == true){
		palindromeString.insert(it, stringVector.begin(), stringVector.end());
		return true;
	}
	
	else{
		return false;
	}
	
	// Call recursive function, pass in palindromeString and empty vector of strings
	recursiveFindPalindromes(palindromeString, Empty);
}

// Return the palindrome vector, a vector of string vectors
vector< vector<string> > FindPalindrome::toVector() const
{
	return palindromeVector;
}

