#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_COLOUR_NONE
#include "catch.hpp"
#include "FindPalindrome.hpp"
#include "FindPalindrome.cpp"

#include <vector>

// There should be at least one test per FindPalindrome method

//Test that this isn't cool
TEST_CASE( "Test FindPalindrome add a non-allowable word", "[FindPalindrome]" )
{
	INFO("Hint: add a single non-allowable word");
	FindPalindrome b;
	REQUIRE(!b.add("kayak1"));
}

//Test that these aren't cool
TEST_CASE( "Test FindPalindrome add a few non-allowable words", "[FindPalindrome]" )
{
	INFO("Hint: add some non-allowable words");
	FindPalindrome b;
	REQUIRE(!b.add("kayak1"));
	REQUIRE(!b.add("kayak 2"));
	REQUIRE(!b.add("kayak.3"));
}

//Test the default constructor
TEST_CASE( "Test FindPalindrome Default Constructor", "[FindPalindrome]" )
{
	FindPalindrome b;
	REQUIRE(b.toVector().empty());
	REQUIRE(b.number() == 0);
}

TEST_CASE( "Test FindPalindrome Clear Member Function", "[FindPalindrome]" )
{
	FindPalindrome b;
	b.add("kayak");
	b.add({"kayak","byback","plyfac"});
	b.clear();
	
	REQUIRE(b.toVector().empty());
	REQUIRE(b.number() == 0);
}

TEST_CASE( "Test FindPalindrome isPalindrome Member Function", "[FindPalindrome]" )
{
	FindPalindrome b, v;
	vector<string> a = {"Was", "it", "a", "car", "or", "a", "cat", "I", "saw"};

		
	REQUIRE(v.add("kayak") == true);
	REQUIRE(b.add(a) == true);
}
